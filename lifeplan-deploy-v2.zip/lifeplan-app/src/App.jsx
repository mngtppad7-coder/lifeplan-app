import { useState, useMemo, useEffect, useRef } from "react";
import { AreaChart, Area, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer } from "recharts";

const formatMan = (v) => `${Math.round(v).toLocaleString()}万円`;

const C = {
  bg: "#F4F7FA", panel: "#FFFFFF", dark: "#1A2332",
  accent: "#3B82F6", green: "#10B981",
  border: "#E2E8F0", text: "#1E293B", muted: "#94A3B8",
  red: "#EF4444", yellow: "#F59E0B", purple: "#8B5CF6",
  orange: "#F97316",
};

// 期間定義: 2026-2030 / 2031-2035 / 2036-2050 / 2051-2070
// 本人31歳(2026)基準で経過年数に変換
// 期間1: year 0-4, 期間2: year 5-9, 期間3: year 10-24, 期間4: year 25-44
const PERIOD_LABELS = ["2026〜2030", "2031〜2035", "2036〜2050", "2051〜2070"];

const DEFAULTS = {
  // 本人
  myAge: 31, myTakeHome: 578, myIncomeGrowth: 1.5,
  myRetireAge: 65, myPension: 181, myCash: 100, myNisa: 100,
  // 妻
  spouseAge: 29, spouseTakeHome: 286, spouseIncomeGrowth: 1.0,
  spouseRetireAge: 63, spousePension: 128, spouseCash: 1000, spouseNisa: 0,
  // 子供
  child1Age: 2, child2Age: 0,
  // 生活費（固定・年額）
  food: 72, daily: 10.8, comm: 14.4, transport: 14.4,
  leisure: 36, insurance: 89, clothing: 10.8, medical: 9.6, other: 26.4,
  // 教育費
  eduNursery: 30, eduElementary: 60, eduJunior: 114, eduHigh: 97, eduCollege: 103,

  // 期間別: 家賃（年額）
  rent_p: [132, 132, 0, 0],
  // 期間別: 本人NISA・積立投資枠（上限120万/年）
  myNisaTsumi_p: [120, 120, 120, 0],
  // 期間別: 本人NISA・成長投資枠（上限240万/年）
  myNisaGrowth_p: [0, 0, 0, 0],
  // 期間別: 妻NISA・積立投資枠（上限120万/年）
  spouseNisaTsumi_p: [0, 60, 120, 0],
  // 期間別: 妻NISA・成長投資枠（上限240万/年）
  spouseNisaGrowth_p: [0, 0, 0, 0],
  // 期間別: 本人証券口座（年額）
  myStockAnnual_p: [0, 0, 60, 0],
  // 期間別: 妻証券口座（年額）
  spouseStockAnnual_p: [0, 0, 0, 0],

  // 利回り
  myNisaReturn: 5.0, spouseNisaReturn: 5.0,
  myStockReturn: 6.0, spouseStockReturn: 6.0,
  cashReturn: 0.5,

  // 退職金
  myRetireBonus: 2000,       // 本人退職金（PDF: 2000万）
  spouseRetireBonus: 0,      // 妻退職金

  // 住宅（現金一括）
  houseYear: 5,              // 購入予定（何年後）
  houseCashPrice: 0,         // 現金購入額（0=購入しない）
  houseInvestWithdraw: 0,    // 購入時に投資から現金に戻す金額（万円）
  houseInvestSource: "nisa", // 取崩し元: nisa / stock / both
  // ローン（参考用・現金一括の場合は不要）
  houseLoan: 0, loanRate: 1.2, loanYears: 35,
  lifeExpectancy: 90,
  // ライフイベント（突発的な一時出費）
  events: [
    { id: 1, name: "車の購入", year: 3, amount: 300, icon: "🚗" },
    { id: 2, name: "家電・家具", year: 6, amount: 100, icon: "📺" },
  ],
};

// 期間インデックス取得
const getPeriodIdx = (year) => {
  if (year <= 4) return 0;
  if (year <= 9) return 1;
  if (year <= 24) return 2;
  return 3;
};

const Field = ({ label, value, onChange, min, max, step = 1, unit = "" }) => (
  <div style={{ padding: "11px 0", borderBottom: `1px solid ${C.border}` }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 7 }}>
      <span style={{ fontSize: 13, color: C.text, flex: 1, paddingRight: 8 }}>{label}</span>
      <span style={{ fontSize: 13, fontWeight: 700, color: C.dark, background: "#F1F5F9", padding: "2px 8px", borderRadius: 16, border: `1px solid ${C.border}`, whiteSpace: "nowrap" }}>
        {typeof value === "number" && !Number.isInteger(value) ? value.toFixed(1) : value.toLocaleString()}{unit}
      </span>
    </div>
    <input type="range" min={min} max={max} step={step} value={value}
      onChange={e => onChange(Number(e.target.value))}
      style={{ width: "100%", accentColor: C.accent, cursor: "pointer" }} />
    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: C.muted, marginTop: 2 }}>
      <span>{min}{unit}</span><span>{max}{unit}</span>
    </div>
  </div>
);

// 期間別スライダーグループ
const PeriodFields = ({ label, values, onChange, min, max, step = 1, unit = "" }) => (
  <div style={{ marginBottom: 4 }}>
    <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 6 }}>{label}</div>
    {PERIOD_LABELS.map((pl, i) => (
      <div key={i} style={{ padding: "9px 0 9px 10px", borderLeft: `3px solid ${[C.accent, C.green, C.yellow, C.purple][i]}`, marginBottom: 8, background: "#F8FAFC", borderRadius: "0 8px 8px 0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
          <span style={{ fontSize: 11, color: C.muted, fontWeight: 600 }}>{pl}</span>
          <span style={{ fontSize: 13, fontWeight: 700, color: C.dark }}>{values[i].toLocaleString()}{unit}</span>
        </div>
        <input type="range" min={min} max={max} step={step} value={values[i]}
          onChange={e => { const nv = [...values]; nv[i] = Number(e.target.value); onChange(nv); }}
          style={{ width: "100%", accentColor: [C.accent, C.green, C.yellow, C.purple][i], cursor: "pointer" }} />
      </div>
    ))}
  </div>
);

const SH = ({ title, icon, color }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "16px 0 4px" }}>
    <span style={{ fontSize: 15 }}>{icon}</span>
    <span style={{ fontSize: 13, fontWeight: 700, color: color || C.accent }}>{title}</span>
  </div>
);

const KpiCard = ({ label, value, sub, warn, ok }) => (
  <div style={{ background: C.panel, border: `1.5px solid ${warn ? C.red : ok ? C.green : C.border}`, borderRadius: 14, padding: "11px 12px" }}>
    <div style={{ fontSize: 10, color: C.muted, fontWeight: 600, marginBottom: 3 }}>{label}</div>
    <div style={{ fontSize: 16, fontWeight: 800, color: warn ? C.red : ok ? C.green : C.dark, lineHeight: 1.2 }}>{value}</div>
    <div style={{ fontSize: 10, color: C.muted, marginTop: 3 }}>{sub}</div>
  </div>
);

const CT = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: C.dark, borderRadius: 10, padding: "10px 14px", fontSize: 12 }}>
      <div style={{ color: "#93C5FD", fontWeight: 700, marginBottom: 6 }}>{label}歳</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color, marginBottom: 2 }}>{p.name}: <strong>{Math.round(p.value).toLocaleString()}万円</strong></div>
      ))}
    </div>
  );
};

const TABS = [
  { icon: "📊", label: "結果" },
  { icon: "👤", label: "プロフィール" },
  { icon: "💸", label: "支出" },
  { icon: "📈", label: "投資" },
  { icon: "🏠", label: "住宅" },
  { icon: "🎯", label: "イベント" },
];

const INV_COLORS = { myNisa: "#10B981", spouseNisa: "#34D399", myStock: "#3B82F6", spouseStock: "#93C5FD", cash: "#F59E0B" };

export default function LifePlan() {
  const [p, setP] = useState(() => {
    try {
      const hash = window.location.hash.slice(1);
      if (hash) {
        if (hash.startsWith("s=")) {
          // スリム形式（共有リンク）
          const slim = JSON.parse(decodeURIComponent(escape(atob(hash.slice(2)))));
          const evs = (slim.ev || []).map(e => ({ id: e[0], name: e[1], year: e[2], amount: e[3] }));
          return { ...DEFAULTS,
            myAge:slim.a,myTakeHome:slim.b,myIncomeGrowth:slim.c,myRetireAge:slim.d,
            myPension:slim.e,myRetireBonus:slim.f,myCash:slim.g,myNisa:slim.h,
            spouseAge:slim.i,spouseTakeHome:slim.j,spouseIncomeGrowth:slim.k,spouseRetireAge:slim.l,
            spousePension:slim.m,spouseRetireBonus:slim.n,spouseCash:slim.o,spouseNisa:slim.q,
            child1Age:slim.r,child2Age:slim.s,
            food:slim.t,daily:slim.u,comm:slim.v,transport:slim.w,leisure:slim.x,
            insurance:slim.y,clothing:slim.z,medical:slim.A,other:slim.B,
            eduNursery:slim.C,eduElementary:slim.D,eduJunior:slim.E,eduHigh:slim.F,eduCollege:slim.G,
            rent_p:slim.H,myNisaTsumi_p:slim.I,myNisaGrowth_p:slim.J,
            spouseNisaTsumi_p:slim.K,spouseNisaGrowth_p:slim.L,
            myStockAnnual_p:slim.M,spouseStockAnnual_p:slim.N,
            myNisaReturn:slim.O,spouseNisaReturn:slim.P,myStockReturn:slim.Q,spouseStockReturn:slim.R,
            cashReturn:slim.S,
            houseYear:slim.T,houseCashPrice:slim.U,houseInvestWithdraw:slim.V,
            houseInvestSource:slim.W,houseLoan:slim.X,loanRate:slim.Y,loanYears:slim.Z,
            lifeExpectancy:slim._,events:evs,
          };
        }
        return { ...DEFAULTS, ...JSON.parse(decodeURIComponent(atob(hash))) };
      }
      const saved = localStorage.getItem("lifeplan_v1");
      if (saved) return { ...DEFAULTS, ...JSON.parse(saved) };
    } catch(e) {}
    return DEFAULTS;
  });
  const [saveStatus, setSaveStatus] = useState(null); // null | "saved" | "loaded" | "copied"
  const [shareUrl, setShareUrl] = useState(null);

  useEffect(() => {
    const loadScript = (src) => {
      if (!document.querySelector(`script[src="${src}"]`)) {
        const s = document.createElement("script"); s.src = src; document.head.appendChild(s);
      }
    };
    loadScript("https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js");
    loadScript("https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js");
  }, []);
  const [showQR, setShowQR] = useState(false);
  const qrRef = useRef(null);
  const [tab, setTab] = useState(0);
  const [printMode, setPrintMode] = useState(false);
  const set = (k) => (v) => setP(prev => ({ ...prev, [k]: v }));
  const setArr = (k) => (v) => setP(prev => ({ ...prev, [k]: v }));

  const annualLiving = p.food + p.daily + p.comm + p.transport + p.leisure + p.clothing + p.medical + p.other;

  const { data, loanMonthlyMan } = useMemo(() => {
    const loanMonthly = p.houseLoan > 0
      ? (p.houseLoan * (p.loanRate/100/12) * Math.pow(1+p.loanRate/100/12, p.loanYears*12)) /
        (Math.pow(1+p.loanRate/100/12, p.loanYears*12) - 1)
      : 0;
    const loanAnnual = loanMonthly * 12;

    let cashAsset = p.myCash + p.spouseCash;
    let myNisaAsset = p.myNisa;
    let spouseNisaAsset = p.spouseNisa;
    let myStockAsset = 0;
    let spouseStockAsset = 0;
    const rows = [];

    for (let age = p.myAge; age <= p.lifeExpectancy; age++) {
      const year = age - p.myAge;
      const pi = getPeriodIdx(year);
      const myRetired = age >= p.myRetireAge;
      const spouseRetired = (p.spouseAge + year) >= p.spouseRetireAge;
      const bothRetired = myRetired && spouseRetired;

      // 収入
      const myInc = myRetired ? p.myPension : p.myTakeHome * Math.pow(1+p.myIncomeGrowth/100, year);
      const spouseInc = spouseRetired ? p.spousePension : p.spouseTakeHome * Math.pow(1+p.spouseIncomeGrowth/100, year);
      const income = myInc + spouseInc;

      // 退職金（退職した年に現金へ一括加算）
      const myRetireBonus = (age === p.myRetireAge) ? p.myRetireBonus : 0;
      const spouseRetireBonus = ((p.spouseAge + year) === p.spouseRetireAge) ? p.spouseRetireBonus : 0;

      // 家賃（期間別）: 購入後（現金・ローン問わず）は0
      const hasBought = (p.houseCashPrice > 0 || p.houseLoan > 0) && year >= p.houseYear;
      const rentY = hasBought ? 0 : p.rent_p[pi];

      // 現金購入: 購入年に一括で現金から引く
      const cashPurchaseThisYear = (p.houseCashPrice > 0 && year === p.houseYear) ? p.houseCashPrice : 0;

      // ローン
      const loanCost = year >= p.houseYear && year < p.houseYear + p.loanYears && p.houseLoan > 0 ? loanAnnual : 0;

      // 教育費
      const ed = (ca0) => {
        if (ca0 < 0) return 0;
        const ca = ca0 + year;
        if (ca >= 0 && ca < 3) return p.eduNursery;
        if (ca >= 3 && ca < 6) return p.eduNursery * 0.5;
        if (ca >= 6 && ca < 12) return p.eduElementary;
        if (ca >= 12 && ca < 15) return p.eduJunior;
        if (ca >= 15 && ca < 18) return p.eduHigh;
        if (ca >= 18 && ca < 22) return p.eduCollege;
        return 0;
      };
      const eduCost = ed(p.child1Age) + ed(p.child2Age);

      // 期間別投資積立
      const myNisaTsumiC = !bothRetired ? p.myNisaTsumi_p[pi] : 0;
      const myNisaGrowthC = !bothRetired ? p.myNisaGrowth_p[pi] : 0;
      const spouseNisaTsumiC = !bothRetired ? p.spouseNisaTsumi_p[pi] : 0;
      const spouseNisaGrowthC = !bothRetired ? p.spouseNisaGrowth_p[pi] : 0;
      const myNisaC = myNisaTsumiC + myNisaGrowthC;
      const spouseNisaC = spouseNisaTsumiC + spouseNisaGrowthC;
      const myStockC = !bothRetired ? p.myStockAnnual_p[pi] : 0;
      const spouseStockC = !bothRetired ? p.spouseStockAnnual_p[pi] : 0;
      const investTotal = myNisaC + spouseNisaC + myStockC + spouseStockC;

      // ライフイベント（当該年の一時出費を合算）
      const eventCost = p.events.filter(ev => ev.year === year).reduce((s, ev) => s + ev.amount, 0);

      const totalCost = annualLiving + rentY + loanCost + eduCost + p.insurance + investTotal;
      const cashFlow = income - totalCost;

      // 資産更新
      myNisaAsset = myNisaAsset * (1 + p.myNisaReturn/100) + myNisaC;
      spouseNisaAsset = spouseNisaAsset * (1 + p.spouseNisaReturn/100) + spouseNisaC;
      myStockAsset = myStockAsset * (1 + p.myStockReturn/100) + myStockC;
      spouseStockAsset = spouseStockAsset * (1 + p.spouseStockReturn/100) + spouseStockC;
      // 退職金を現金に加算、ライフイベント費用を差し引く
      cashAsset = cashAsset * (1 + p.cashReturn/100) + cashFlow + myRetireBonus + spouseRetireBonus - cashPurchaseThisYear - eventCost;

      // 購入年: 指定額を投資から現金へ移動
      let investFilled = 0;
      if (p.houseInvestWithdraw > 0 && year === p.houseYear) {
        const withdraw = p.houseInvestWithdraw;
        if (p.houseInvestSource === "nisa") {
          const available = myNisaAsset + spouseNisaAsset;
          const take = Math.min(withdraw, available);
          const ratio = available > 0 ? take / available : 0;
          myNisaAsset = Math.max(0, myNisaAsset * (1 - ratio));
          spouseNisaAsset = Math.max(0, spouseNisaAsset * (1 - ratio));
          cashAsset += take; investFilled = take;
        } else if (p.houseInvestSource === "stock") {
          const available = myStockAsset + spouseStockAsset;
          const take = Math.min(withdraw, available);
          const ratio = available > 0 ? take / available : 0;
          myStockAsset = Math.max(0, myStockAsset * (1 - ratio));
          spouseStockAsset = Math.max(0, spouseStockAsset * (1 - ratio));
          cashAsset += take; investFilled = take;
        } else {
          const nisaAvail = myNisaAsset + spouseNisaAsset;
          const takeNisa = Math.min(withdraw, nisaAvail);
          const ratioN = nisaAvail > 0 ? takeNisa / nisaAvail : 0;
          myNisaAsset = Math.max(0, myNisaAsset * (1 - ratioN));
          spouseNisaAsset = Math.max(0, spouseNisaAsset * (1 - ratioN));
          const remaining = withdraw - takeNisa;
          const stockAvail = myStockAsset + spouseStockAsset;
          const takeStock = Math.min(remaining, stockAvail);
          const ratioS = stockAvail > 0 ? takeStock / stockAvail : 0;
          myStockAsset = Math.max(0, myStockAsset * (1 - ratioS));
          spouseStockAsset = Math.max(0, spouseStockAsset * (1 - ratioS));
          cashAsset += takeNisa + takeStock; investFilled = takeNisa + takeStock;
        }
      }

      const total = cashAsset + myNisaAsset + spouseNisaAsset + myStockAsset + spouseStockAsset;

      rows.push({
        age, income: Math.round(income),
        investFilled: Math.round(investFilled),
        eventCost: Math.round(eventCost),
        livingCost: Math.round(annualLiving + rentY + loanCost + p.insurance),
        eduCost: Math.round(eduCost),
        invest: Math.round(investTotal),
        cashAsset: Math.round(cashAsset),
        myNisaAsset: Math.round(myNisaAsset),
        spouseNisaAsset: Math.round(spouseNisaAsset),
        myStockAsset: Math.round(myStockAsset),
        spouseStockAsset: Math.round(spouseStockAsset),
        total: Math.round(total),
      });
    }
    return { data: rows, loanMonthlyMan: Math.round(loanMonthly) };
  }, [p, annualLiving]);

  const finalTotal = data[data.length-1]?.total ?? 0;
  const crossZeroAge = data.find(d => d.total < 0)?.age;
  const peakTotal = Math.max(...data.map(d => d.total));
  const retireData = data.find(d => d.age === p.myRetireAge);
  const isOk = finalTotal > 0;
  const totalAssetNow = p.myCash + p.spouseCash + p.myNisa + p.spouseNisa;

  // 現在の月間投資合計（期間1）
  const currentMonthlyInvest = (p.myNisaTsumi_p[0] + p.myNisaGrowth_p[0] + p.spouseNisaTsumi_p[0] + p.spouseNisaGrowth_p[0] + p.myStockAnnual_p[0] + p.spouseStockAnnual_p[0]) / 12;

  // ── エクスポート関数 (SheetJS CDN via script tag) ─────────────────
  const buildRows = () => data.map(d => ({
    "西暦": 2026 + (d.age - p.myAge),
    "年齢（本人）": d.age,
    "年齢（妻）": p.spouseAge + (d.age - p.myAge),
    "手取り収入合計（万円）": d.income,
    "生活費（万円）": d.livingCost,
    "教育費（万円）": d.eduCost,
    "投資積立（万円）": d.invest,
    "年間収支（万円）": d.income - d.livingCost - d.eduCost - d.invest,
    "現金・預金残高（万円）": d.cashAsset,
    "本人NISA残高（万円）": d.myNisaAsset,
    "妻NISA残高（万円）": d.spouseNisaAsset,
    "本人証券口座（万円）": d.myStockAsset,
    "妻証券口座（万円）": d.spouseStockAsset,
    "総資産（万円）": d.total,
  }));

  const exportExcel = () => {
    const XLSX = window.XLSX;
    if (!XLSX) { alert("読み込み中です。しばらくお待ちください。"); return; }
    const rows = buildRows();
    const wb = XLSX.utils.book_new();

    // シート1: キャッシュフロー表
    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = Object.keys(rows[0]).map(() => ({ wch: 22 }));
    XLSX.utils.book_append_sheet(wb, ws, "キャッシュフロー");

    // シート2: 設定サマリー
    const settings = [
      ["項目", "本人", "妻"],
      ["手取り年収（万円）", p.myTakeHome, p.spouseTakeHome],
      ["収入上昇率（%）", p.myIncomeGrowth, p.spouseIncomeGrowth],
      ["退職年齢（歳）", p.myRetireAge, p.spouseRetireAge],
      ["年金（万円/年）", p.myPension, p.spousePension],
      ["退職金（万円）", p.myRetireBonus, p.spouseRetireBonus],
      ["現金残高（万円）", p.myCash, p.spouseCash],
      ["NISA残高（万円）", p.myNisa, p.spouseNisa],
      ["---生活費---", "", ""],
      ["家賃2026-30（万円/年）", p.rent_p[0], ""],
      ["家賃2031-35（万円/年）", p.rent_p[1], ""],
      ["食費（万円/年）", p.food, ""],
      ["保険料（万円/年）", p.insurance, ""],
      ["---投資設定---", "", ""],
      ["本人NISA積立枠（万円/年）", p.myNisaTsumi_p[0], ""],
      ["本人NISA成長枠（万円/年）", p.myNisaGrowth_p[0], ""],
      ["妻NISA積立枠（万円/年）", p.spouseNisaTsumi_p[0], ""],
      ["妻NISA成長枠（万円/年）", p.spouseNisaGrowth_p[0], ""],
      ["NISA利回り本人（%）", p.myNisaReturn, p.spouseNisaReturn],
      ["---住宅---", "", ""],
      ["購入予定（何年後）", p.houseYear, ""],
      ["購入価格（万円）", p.houseCashPrice, ""],
      ["---シミュレーション結果---", "", ""],
      ["退職時総資産（万円）", retireData?.total ?? 0, ""],
      ["資産ピーク（万円）", peakTotal, ""],
      ["最終資産（万円）", finalTotal, ""],
      crossZeroAge ? ["⚠ 資産枯渇年齢（歳）", crossZeroAge, ""] : ["✓ 完走", `${p.lifeExpectancy}歳まで安全`, ""],
    ];
    const ws2 = XLSX.utils.aoa_to_sheet(settings);
    ws2["!cols"] = [{ wch: 28 }, { wch: 16 }, { wch: 16 }];
    XLSX.utils.book_append_sheet(wb, ws2, "設定サマリー");

    XLSX.writeFile(wb, "ライフプラン.xlsx");
  };

  const exportCSV = () => {
    const rows = buildRows();
    const headers = Object.keys(rows[0]);
    const csv = [
      headers.join(","),
      ...rows.map(r => headers.map(h => r[h]).join(","))
    ].join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "ライフプラン.csv";
    a.click();
  };

  const saveData = () => {
    try {
      localStorage.setItem("lifeplan_v1", JSON.stringify(p));
      setSaveStatus("saved");
      setTimeout(() => setSaveStatus(null), 2500);
    } catch(e) { alert("保存できませんでした"); }
  };

  const loadData = () => {
    try {
      const saved = localStorage.getItem("lifeplan_v1");
      if (saved) { setP({ ...DEFAULTS, ...JSON.parse(saved) }); setSaveStatus("loaded"); setTimeout(() => setSaveStatus(null), 2500); }
      else alert("保存データが見つかりません");
    } catch(e) { alert("読み込みに失敗しました"); }
  };

  const resetData = () => {
    if (window.confirm("設定をリセットしますか？保存データは消えません。")) setP(DEFAULTS);
  };

  const generateShareLink = (showQRMode = false) => {
    try {
      // 数値だけを配列で詰め込み、配列・文字列フィールドは別途 — URLを短縮する
      const slim = {
        a: p.myAge, b: p.myTakeHome, c: p.myIncomeGrowth, d: p.myRetireAge,
        e: p.myPension, f: p.myRetireBonus, g: p.myCash, h: p.myNisa,
        i: p.spouseAge, j: p.spouseTakeHome, k: p.spouseIncomeGrowth, l: p.spouseRetireAge,
        m: p.spousePension, n: p.spouseRetireBonus, o: p.spouseCash, q: p.spouseNisa,
        r: p.child1Age, s: p.child2Age,
        t: p.food, u: p.daily, v: p.comm, w: p.transport, x: p.leisure,
        y: p.insurance, z: p.clothing, A: p.medical, B: p.other,
        C: p.eduNursery, D: p.eduElementary, E: p.eduJunior, F: p.eduHigh, G: p.eduCollege,
        H: p.rent_p, I: p.myNisaTsumi_p, J: p.myNisaGrowth_p,
        K: p.spouseNisaTsumi_p, L: p.spouseNisaGrowth_p,
        M: p.myStockAnnual_p, N: p.spouseStockAnnual_p,
        O: p.myNisaReturn, P: p.spouseNisaReturn, Q: p.myStockReturn, R: p.spouseStockReturn,
        S: p.cashReturn,
        T: p.houseYear, U: p.houseCashPrice, V: p.houseInvestWithdraw,
        W: p.houseInvestSource, X: p.houseLoan, Y: p.loanRate, Z: p.loanYears,
        _: p.lifeExpectancy,
        ev: p.events.map(e => [e.id, e.name, e.year, e.amount]),
      };
      const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(slim))));
      const base = window.location.href.split("#")[0];
      const url = base + "#s=" + encoded;
      setShareUrl(url);
      // QRコード生成
      setShowQR(true);
      setTimeout(() => {
        if (qrRef.current) {
          qrRef.current.innerHTML = "";
          if (window.QRCode) {
            new window.QRCode(qrRef.current, { text: url, width: 200, height: 200, colorDark: "#1A2332", colorLight: "#ffffff", correctLevel: window.QRCode.CorrectLevel.M });
          }
        }
      }, 100);
      if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(() => { setSaveStatus("copied"); setTimeout(() => setSaveStatus(null), 3000); });
      }
    } catch(e) { alert("共有リンクの生成に失敗しました"); }
  };

  const printPDF = () => {
    setPrintMode(true);
    setTimeout(() => { window.print(); setPrintMode(false); }, 400);
  };

  return (
    <div style={{ maxWidth: 480, margin: "0 auto", minHeight: "100vh", background: C.bg, fontFamily: "'Hiragino Kaku Gothic Pro','Noto Sans JP',sans-serif", color: C.text, paddingBottom: 76 }}>
      {/* ヘッダー */}
      <div style={{ background: C.dark, padding: "13px 18px 11px", position: "sticky", top: 0, zIndex: 100, boxShadow: "0 2px 20px rgba(0,0,0,0.4)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: 14, fontWeight: 800, color: "#E2E8F0" }}>ライフプランシミュレーター</div>
            <div style={{ fontSize: 10, color: C.muted, marginTop: 1 }}>本人31歳・手取578万 ／ 妻29歳・手取286万</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 11, color: isOk ? C.green : C.red, fontWeight: 700 }}>
              {isOk ? `✓ ${p.lifeExpectancy}歳まで安全` : `⚠ ${crossZeroAge}歳で枯渇`}
            </div>
            <div style={{ fontSize: 11, color: "#CBD5E1", fontWeight: 600, marginTop: 1 }}>現在資産 {formatMan(totalAssetNow)}</div>
            {(() => { try { return localStorage.getItem("lifeplan_v1") ? <div style={{ fontSize: 9, color: "#10B981", marginTop: 2 }}>💾 保存済み</div> : null; } catch(e) { return null; } })()}
          </div>
        </div>
      </div>

      {/* 印刷専用スタイル */}
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #print-area, #print-area * { visibility: visible !important; }
          #print-area { position: fixed !important; top: 0; left: 0; width: 100%; z-index: 9999; background: white; }
          @page { size: A4 portrait; margin: 12mm 10mm; }
        }
      `}</style>

      {/* 印刷専用レイアウト */}
      {printMode && (
        <div id="print-area" style={{ background: "#fff", padding: "0 8px", fontFamily: "'Hiragino Kaku Gothic Pro','Noto Sans JP',sans-serif", color: "#1E293B" }}>
          {/* 印刷ヘッダー */}
          <div style={{ borderBottom: "2px solid #1A2332", paddingBottom: 8, marginBottom: 14, display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
            <div>
              <div style={{ fontSize: 16, fontWeight: 800, color: "#1A2332" }}>ライフプランシミュレーション</div>
              <div style={{ fontSize: 10, color: "#94A3B8", marginTop: 2 }}>本人{p.myAge}歳・手取{p.myTakeHome}万 ／ 妻{p.spouseAge}歳・手取{p.spouseTakeHome}万　出力日: {new Date().toLocaleDateString("ja-JP")}</div>
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: isOk ? "#10B981" : "#EF4444" }}>
              {isOk ? `✓ ${p.lifeExpectancy}歳まで資産維持` : `⚠ ${crossZeroAge}歳で資産枯渇`}
            </div>
          </div>

          {/* KPIグリッド */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 14 }}>
            {[
              ["退職時総資産", formatMan(retireData?.total ?? 0), `${p.myRetireAge}歳`],
              ["資産ピーク", formatMan(peakTotal), "最大蓄積額"],
              ["最終資産", formatMan(finalTotal), `${p.lifeExpectancy}歳`],
              ["月間投資(現在)", `${Math.round(currentMonthlyInvest)}万円`, "NISA+証券"],
            ].map(([l,v,s]) => (
              <div key={l} style={{ border: "1px solid #E2E8F0", borderRadius: 8, padding: "8px 10px", background: "#F8FAFC" }}>
                <div style={{ fontSize: 9, color: "#94A3B8", marginBottom: 2 }}>{l}</div>
                <div style={{ fontSize: 13, fontWeight: 800, color: "#1A2332" }}>{v}</div>
                <div style={{ fontSize: 9, color: "#94A3B8" }}>{s}</div>
              </div>
            ))}
          </div>

          {/* 資産推移グラフ */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#3B82F6", marginBottom: 6 }}>📈 総資産推移</div>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={data} margin={{ top: 4, right: 4, left: -10, bottom: 0 }}>
                <defs>
                  {[["pgc","#F59E0B"],["pgn","#10B981"],["pgn2","#34D399"],["pgs","#3B82F6"],["pgs2","#93C5FD"]].map(([id,c]) => (
                    <linearGradient key={id} id={id} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={c} stopOpacity={0.6}/><stop offset="95%" stopColor={c} stopOpacity={0.05}/>
                    </linearGradient>
                  ))}
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0"/>
                <XAxis dataKey="age" tick={{ fontSize: 9 }} tickFormatter={v=>`${v}歳`} interval={4}/>
                <YAxis tick={{ fontSize: 9 }} tickFormatter={v=>`${Math.round(v/100)}百万`} width={44}/>
                <ReferenceLine x={p.myRetireAge} stroke="#F59E0B" strokeDasharray="4 2"/>
                <ReferenceLine y={0} stroke="#EF4444" strokeWidth={1.5}/>
                <Area type="monotone" dataKey="cashAsset" name="現金" stroke="#F59E0B" fill="url(#pgc)" strokeWidth={1} dot={false} stackId="a"/>
                <Area type="monotone" dataKey="myNisaAsset" name="本人NISA" stroke="#10B981" fill="url(#pgn)" strokeWidth={1} dot={false} stackId="a"/>
                <Area type="monotone" dataKey="spouseNisaAsset" name="妻NISA" stroke="#34D399" fill="url(#pgn2)" strokeWidth={1} dot={false} stackId="a"/>
                <Area type="monotone" dataKey="myStockAsset" name="本人証券" stroke="#3B82F6" fill="url(#pgs)" strokeWidth={1} dot={false} stackId="a"/>
                <Area type="monotone" dataKey="spouseStockAsset" name="妻証券" stroke="#93C5FD" fill="url(#pgs2)" strokeWidth={1} dot={false} stackId="a"/>
              </AreaChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", gap: 10, justifyContent: "center", fontSize: 9, marginTop: 4 }}>
              {[["現金","#F59E0B"],["本人NISA","#10B981"],["妻NISA","#34D399"],["本人証券","#3B82F6"],["妻証券","#93C5FD"]].map(([l,c])=>(
                <span key={l} style={{color:c,fontWeight:700}}>■ {l}</span>
              ))}
            </div>
          </div>

          {/* キャッシュフロー表（10年ごとのサマリー） */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#3B82F6", marginBottom: 6 }}>💴 キャッシュフロー（5年ごと）</div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 9 }}>
              <thead>
                <tr style={{ background: "#1A2332", color: "#fff" }}>
                  {["年齢","収入","生活費","教育費","投資","現金残高","NISA残高","証券残高","総資産"].map(h=>(
                    <th key={h} style={{ padding: "5px 4px", textAlign: "right", fontWeight: 600, whiteSpace: "nowrap" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.filter((_,i) => i % 5 === 0).map((d, i) => (
                  <tr key={d.age} style={{ background: i % 2 === 0 ? "#F8FAFC" : "#fff", borderBottom: "1px solid #E2E8F0" }}>
                    <td style={{ padding: "4px", textAlign: "right", fontWeight: 700 }}>{d.age}歳</td>
                    <td style={{ padding: "4px", textAlign: "right" }}>{d.income.toLocaleString()}</td>
                    <td style={{ padding: "4px", textAlign: "right" }}>{d.livingCost.toLocaleString()}</td>
                    <td style={{ padding: "4px", textAlign: "right" }}>{d.eduCost.toLocaleString()}</td>
                    <td style={{ padding: "4px", textAlign: "right" }}>{d.invest.toLocaleString()}</td>
                    <td style={{ padding: "4px", textAlign: "right", color: d.cashAsset < 0 ? "#EF4444" : "#1E293B" }}>{d.cashAsset.toLocaleString()}</td>
                    <td style={{ padding: "4px", textAlign: "right", color: "#10B981" }}>{(d.myNisaAsset+d.spouseNisaAsset).toLocaleString()}</td>
                    <td style={{ padding: "4px", textAlign: "right", color: "#3B82F6" }}>{(d.myStockAsset+d.spouseStockAsset).toLocaleString()}</td>
                    <td style={{ padding: "4px", textAlign: "right", fontWeight: 700, color: d.total < 0 ? "#EF4444" : "#1A2332" }}>{d.total.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{ fontSize: 8, color: "#94A3B8", marginTop: 4 }}>単位: 万円　■黄色縦線 = 退職年</div>
          </div>

          {/* 設定サマリー */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div style={{ border: "1px solid #E2E8F0", borderRadius: 8, padding: 10 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#3B82F6", marginBottom: 6 }}>👤 人物設定</div>
              {[
                ["本人退職年齢", `${p.myRetireAge}歳`],
                ["本人年金", `${p.myPension}万/年`],
                ["本人退職金", `${p.myRetireBonus}万`],
                ["妻退職年齢", `${p.spouseRetireAge}歳`],
                ["妻年金", `${p.spousePension}万/年`],
                ["妻退職金", `${p.spouseRetireBonus}万`],
              ].map(([l,v])=>(
                <div key={l} style={{ display:"flex", justifyContent:"space-between", fontSize:9, padding:"2px 0", borderBottom:"1px solid #F1F5F9" }}>
                  <span style={{color:"#94A3B8"}}>{l}</span><span style={{fontWeight:600}}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{ border: "1px solid #E2E8F0", borderRadius: 8, padding: 10 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#10B981", marginBottom: 6 }}>📈 投資設定</div>
              {[
                ["本人NISA積立枠", `${p.myNisaTsumi_p[0]}万/年`],
                ["本人NISA成長枠", `${p.myNisaGrowth_p[0]}万/年`],
                ["妻NISA積立枠", `${p.spouseNisaTsumi_p[0]}万/年`],
                ["妻NISA成長枠", `${p.spouseNisaGrowth_p[0]}万/年`],
                ["NISA利回り", `本人${p.myNisaReturn}% / 妻${p.spouseNisaReturn}%`],
                ["住宅購入", p.houseCashPrice > 0 ? `${p.houseYear}年後・${p.houseCashPrice}万` : "予定なし"],
              ].map(([l,v])=>(
                <div key={l} style={{ display:"flex", justifyContent:"space-between", fontSize:9, padding:"2px 0", borderBottom:"1px solid #F1F5F9" }}>
                  <span style={{color:"#94A3B8"}}>{l}</span><span style={{fontWeight:600}}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div style={{ padding: "14px 14px 0" }}>

        {/* === TAB 0: 結果 === */}
        {tab === 0 && (<>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
            <KpiCard label="退職時・総資産" value={formatMan(retireData?.total ?? 0)} sub={`${p.myRetireAge}歳時点`} ok={(retireData?.total ?? 0) > 0} />
            <KpiCard label="資産ピーク" value={formatMan(peakTotal)} sub="最大蓄積額" />
            <KpiCard label={crossZeroAge ? "資産枯渇年齢" : "最終資産"} value={crossZeroAge ? `${crossZeroAge}歳` : formatMan(finalTotal)} sub={crossZeroAge ? "早めの対策を" : `${p.lifeExpectancy}歳時点`} warn={!!crossZeroAge} ok={!crossZeroAge && finalTotal > 0} />
            <KpiCard label="月間投資（現在）" value={`${Math.round(currentMonthlyInvest)}万円`} sub="NISA+証券合計" />
          </div>

          {/* 現在の資産内訳 */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "14px", marginBottom: 12, border: `1px solid ${C.border}` }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.accent, marginBottom: 10 }}>💼 現在の資産内訳</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {[["本人・現金", p.myCash, "#3B82F6"],["本人・NISA", p.myNisa, C.green],["妻・現金", p.spouseCash, C.purple],["妻・NISA", p.spouseNisa, "#34D399"]].map(([l,v,c]) => (
                <div key={l} style={{ background: "#F8FAFC", borderRadius: 10, padding: "9px 12px", borderLeft: `3px solid ${c}` }}>
                  <div style={{ fontSize: 10, color: C.muted }}>{l}</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: C.dark }}>{v.toLocaleString()}万円</div>
                </div>
              ))}
            </div>
          </div>

          {/* 資産推移 */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "14px 10px 10px", marginBottom: 12, border: `1px solid ${C.border}` }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.accent, marginBottom: 10, paddingLeft: 4 }}>📈 総資産推移（内訳別）</div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={data} margin={{ top: 4, right: 4, left: -10, bottom: 0 }}>
                <defs>
                  {[["gc",C.yellow],["gn",C.green],["gn2","#34D399"],["gs",C.accent],["gs2","#93C5FD"]].map(([id,c]) => (
                    <linearGradient key={id} id={id} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={c} stopOpacity={0.7} />
                      <stop offset="95%" stopColor={c} stopOpacity={0.05} />
                    </linearGradient>
                  ))}
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                <XAxis dataKey="age" tick={{ fontSize: 10, fill: C.muted }} tickFormatter={v=>`${v}歳`} interval={9} />
                <YAxis tick={{ fontSize: 10, fill: C.muted }} tickFormatter={v=>`${Math.round(v/100)}百万`} width={46} />
                <Tooltip content={<CT />} />
                <ReferenceLine x={p.myRetireAge} stroke={C.yellow} strokeDasharray="5 3" />
                <ReferenceLine y={0} stroke={C.red} strokeWidth={1.5} />
                {p.events.map(ev => (
                  <ReferenceLine key={ev.id} x={p.myAge+ev.year} stroke="#8B5CF6" strokeDasharray="3 3" strokeWidth={1.5} label={{ value: ev.name, position: "top", fontSize: 8, fill: "#8B5CF6" }} />
                ))}
                <Area type="monotone" dataKey="cashAsset" name="現金" stroke={C.yellow} fill="url(#gc)" strokeWidth={1.5} dot={false} stackId="a" />
                <Area type="monotone" dataKey="myNisaAsset" name="本人NISA" stroke={C.green} fill="url(#gn)" strokeWidth={1.5} dot={false} stackId="a" />
                <Area type="monotone" dataKey="spouseNisaAsset" name="妻NISA" stroke="#34D399" fill="url(#gn2)" strokeWidth={1.5} dot={false} stackId="a" />
                <Area type="monotone" dataKey="myStockAsset" name="本人証券" stroke={C.accent} fill="url(#gs)" strokeWidth={1.5} dot={false} stackId="a" />
                <Area type="monotone" dataKey="spouseStockAsset" name="妻証券" stroke="#93C5FD" fill="url(#gs2)" strokeWidth={1.5} dot={false} stackId="a" />
              </AreaChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", marginTop: 8 }}>
              {[["現金",C.yellow],["本人NISA",C.green],["妻NISA","#34D399"],["本人証券",C.accent],["妻証券","#93C5FD"]].map(([l,c]) => (
                <span key={l} style={{ fontSize: 10, color: c, fontWeight: 700 }}>■ {l}</span>
              ))}
            </div>
          </div>

          {/* 収支チャート */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "14px 10px 10px", border: `1px solid ${C.border}`, marginBottom: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.accent, marginBottom: 10, paddingLeft: 4 }}>💴 年間収支</div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={data} margin={{ top: 14, right: 4, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                <XAxis dataKey="age" tick={{ fontSize: 10, fill: C.muted }} tickFormatter={v=>`${v}歳`} interval={9} />
                <YAxis tick={{ fontSize: 10, fill: C.muted }} tickFormatter={v=>`${v}万`} width={46} />
                <Tooltip content={<CT />} />
                <ReferenceLine x={p.myRetireAge} stroke={C.yellow} strokeDasharray="5 3" />
                {p.events.map(ev => (
                  <ReferenceLine key={ev.id} x={p.myAge + ev.year} stroke={C.purple} strokeDasharray="3 3" strokeWidth={1.5}
                    label={{ value: `${ev.icon||"💰"}${ev.amount}万`, position: "top", fontSize: 9, fill: C.purple }} />
                ))}
                <Line type="monotone" dataKey="income" name="手取り収入" stroke={C.green} dot={false} strokeWidth={2.5} />
                <Line type="monotone" dataKey="livingCost" name="生活費" stroke={C.red} dot={false} strokeWidth={2} />
                <Line type="monotone" dataKey="invest" name="投資積立" stroke={C.accent} dot={false} strokeWidth={1.5} strokeDasharray="4 2" />
                <Line type="monotone" dataKey="eventCost" name="イベント出費" stroke={C.purple} dot={(props) => {
                  const { cx, cy, payload } = props;
                  if (!payload.eventCost) return null;
                  return <circle key={cx} cx={cx} cy={cy} r={5} fill={C.purple} stroke="#fff" strokeWidth={2} />;
                }} strokeWidth={0} />
              </LineChart>
            </ResponsiveContainer>
            <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 8, fontSize: 11, flexWrap: "wrap" }}>
              <span style={{ color: C.green, fontWeight: 700 }}>─ 収入</span>
              <span style={{ color: C.red, fontWeight: 700 }}>─ 生活費</span>
              <span style={{ color: C.accent, fontWeight: 700 }}>-- 投資</span>
              <span style={{ color: C.purple, fontWeight: 700 }}>● イベント</span>
            </div>
          </div>

          {/* 保存・読み込み・共有 */}
          <div style={{ background: "linear-gradient(135deg,#1A2332,#0F2027)", borderRadius: 16, padding: "14px 16px", marginBottom: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#E2E8F0", marginBottom: 4 }}>💾 保存・共有</div>
            <div style={{ fontSize: 10, color: "#64748B", marginBottom: 12 }}>このデバイスへの保存、または共有リンクで他のスマホとシミュレーターごと共有できます。</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 10 }}>
              <button onClick={saveData} style={{ padding: "12px 6px", borderRadius: 12, border: "none", cursor: "pointer", background: "linear-gradient(135deg,#7C3AED,#6D28D9)", color: "#fff", fontWeight: 700, fontSize: 12, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <span style={{ fontSize: 18 }}>💾</span><span>保存</span><span style={{ fontSize: 9, opacity: 0.8 }}>このデバイス</span>
              </button>
              <button onClick={loadData} style={{ padding: "12px 6px", borderRadius: 12, border: "none", cursor: "pointer", background: "linear-gradient(135deg,#0369A1,#0284C7)", color: "#fff", fontWeight: 700, fontSize: 12, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <span style={{ fontSize: 18 }}>📂</span><span>読込み</span><span style={{ fontSize: 9, opacity: 0.8 }}>保存済み復元</span>
              </button>
              <button onClick={resetData} style={{ padding: "12px 6px", borderRadius: 12, border: "none", cursor: "pointer", background: "linear-gradient(135deg,#374151,#4B5563)", color: "#fff", fontWeight: 700, fontSize: 12, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <span style={{ fontSize: 18 }}>🔄</span><span>リセット</span><span style={{ fontSize: 9, opacity: 0.8 }}>初期値に戻す</span>
              </button>
            </div>

            <button onClick={() => generateShareLink()} style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: "none", cursor: "pointer", background: "linear-gradient(135deg,#B45309,#D97706)", color: "#fff", fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
              <span style={{ fontSize: 20 }}>📱</span>
              <div style={{ textAlign: "left" }}>
                <div>QRコード＆リンクを生成</div>
                <div style={{ fontSize: 10, fontWeight: 400, opacity: 0.85 }}>QRコードを相手に見せるだけで共有できます</div>
              </div>
            </button>

            {saveStatus && (
              <div style={{ marginTop: 4, marginBottom: 8, background: saveStatus === "saved" ? "#065F46" : saveStatus === "copied" ? "#78350F" : "#1E3A5F", borderRadius: 8, padding: "8px 12px", fontSize: 12, color: "#fff", fontWeight: 700, textAlign: "center" }}>
                {saveStatus === "saved" && "✅ 保存しました！"}
                {saveStatus === "loaded" && "📂 読み込みました！"}
                {saveStatus === "copied" && "✅ リンクもクリップボードにコピー済み"}
              </div>
            )}

            {showQR && shareUrl && (
              <div style={{ background: "#0F172A", borderRadius: 12, padding: "16px", marginTop: 4 }}>
                <div style={{ fontSize: 12, color: "#94A3B8", marginBottom: 10, textAlign: "center" }}>📱 このQRコードを相手のスマホで読み取ってください</div>
                <div style={{ display: "flex", justifyContent: "center", marginBottom: 12 }}>
                  <div ref={qrRef} style={{ background: "#fff", padding: 8, borderRadius: 8, display: "inline-block" }} />
                </div>
                <div style={{ fontSize: 10, color: "#64748B", textAlign: "center", marginBottom: 8 }}>── または ──</div>
                <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 4 }}>リンクを直接コピー（LINEに貼り付け）:</div>
                <div onClick={() => { if(navigator.clipboard) navigator.clipboard.writeText(shareUrl).then(()=>{ setSaveStatus("copied"); setTimeout(()=>setSaveStatus(null),3000); }); }}
                  style={{ background: "#1E293B", borderRadius: 8, padding: "8px 10px", fontSize: 9, color: "#93C5FD", wordBreak: "break-all", cursor: "pointer", border: "1px solid #334155", lineHeight: 1.6 }}>
                  {shareUrl.slice(0, 120)}… <span style={{ color: C.yellow }}>(タップでコピー)</span>
                </div>
                <button onClick={() => setShowQR(false)} style={{ width: "100%", marginTop: 10, padding: "8px", background: "none", border: "1px solid #334155", borderRadius: 8, color: "#64748B", cursor: "pointer", fontSize: 11 }}>閉じる</button>
              </div>
            )}
          </div>

                    {/* エクスポートボタン */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "14px 16px", border: `1px solid ${C.border}`, marginBottom: 4 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.dark, marginBottom: 12 }}>📥 データをエクスポート</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
              <button onClick={exportExcel}
                style={{ padding: "12px 6px", borderRadius: 12, border: "none", cursor: "pointer", background: "linear-gradient(135deg,#166534,#15803d)", color: "#fff", fontWeight: 700, fontSize: 12, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <span style={{ fontSize: 18 }}>📊</span>
                <span>Excel</span>
                <span style={{ fontSize: 9, fontWeight: 400, opacity: 0.8 }}>2シート</span>
              </button>
              <button onClick={exportCSV}
                style={{ padding: "12px 6px", borderRadius: 12, border: "none", cursor: "pointer", background: "linear-gradient(135deg,#1e3a5f,#1d4ed8)", color: "#fff", fontWeight: 700, fontSize: 12, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <span style={{ fontSize: 18 }}>📋</span>
                <span>CSV</span>
                <span style={{ fontSize: 9, fontWeight: 400, opacity: 0.8 }}>全年次</span>
              </button>
              <button onClick={printPDF}
                style={{ padding: "12px 6px", borderRadius: 12, border: "none", cursor: "pointer", background: "linear-gradient(135deg,#7c2d12,#dc2626)", color: "#fff", fontWeight: 700, fontSize: 12, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <span style={{ fontSize: 18 }}>🖨️</span>
                <span>PDF印刷</span>
                <span style={{ fontSize: 9, fontWeight: 400, opacity: 0.8 }}>A4最適化</span>
              </button>
            </div>
            <div style={{ fontSize: 10, color: C.muted, marginTop: 10, textAlign: "center" }}>
              現在の設定値でシミュレーションした結果をダウンロードします
            </div>
          </div>
        </>)}

        {/* === TAB 1: プロフィール === */}
        {tab === 1 && (<>
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.border}`, marginBottom: 12 }}>
            <SH title="本人" icon="👤" color={C.accent} />
            <Field label="年齢" value={p.myAge} onChange={set("myAge")} min={25} max={60} unit="歳" />
            <Field label="手取り年収" value={p.myTakeHome} onChange={set("myTakeHome")} min={200} max={2500} step={10} unit="万円" />
            <Field label="収入上昇率" value={p.myIncomeGrowth} onChange={set("myIncomeGrowth")} min={0} max={5} step={0.5} unit="%" />
            <Field label="退職年齢" value={p.myRetireAge} onChange={set("myRetireAge")} min={55} max={75} unit="歳" />
            <Field label="年金（年額・退職後）" value={p.myPension} onChange={set("myPension")} min={50} max={300} step={5} unit="万円" />
            <Field label="退職金" value={p.myRetireBonus} onChange={set("myRetireBonus")} min={0} max={5000} step={100} unit="万円" />
            <SH title="本人の現在資産" icon="💴" color={C.accent} />
            <Field label="現金・預金" value={p.myCash} onChange={set("myCash")} min={0} max={3000} step={10} unit="万円" />
            <Field label="NISA残高" value={p.myNisa} onChange={set("myNisa")} min={0} max={3000} step={10} unit="万円" />
          </div>
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.border}`, marginBottom: 12 }}>
            <SH title="配偶者" icon="👤" color={C.purple} />
            <Field label="年齢" value={p.spouseAge} onChange={set("spouseAge")} min={20} max={60} unit="歳" />
            <Field label="手取り年収" value={p.spouseTakeHome} onChange={set("spouseTakeHome")} min={0} max={1500} step={10} unit="万円" />
            <Field label="収入上昇率" value={p.spouseIncomeGrowth} onChange={set("spouseIncomeGrowth")} min={0} max={5} step={0.5} unit="%" />
            <Field label="退職年齢" value={p.spouseRetireAge} onChange={set("spouseRetireAge")} min={50} max={75} unit="歳" />
            <Field label="年金（年額・退職後）" value={p.spousePension} onChange={set("spousePension")} min={50} max={250} step={5} unit="万円" />
            <Field label="退職金" value={p.spouseRetireBonus} onChange={set("spouseRetireBonus")} min={0} max={5000} step={100} unit="万円" />
            <SH title="配偶者の現在資産" icon="💴" color={C.purple} />
            <Field label="現金・預金" value={p.spouseCash} onChange={set("spouseCash")} min={0} max={5000} step={10} unit="万円" />
            <Field label="NISA残高" value={p.spouseNisa} onChange={set("spouseNisa")} min={0} max={3000} step={10} unit="万円" />
          </div>
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.border}` }}>
            <SH title="子ども（−1=なし）" icon="👶" color={C.yellow} />
            <Field label="第1子の年齢" value={p.child1Age} onChange={set("child1Age")} min={-1} max={18} unit="歳" />
            <Field label="第2子の年齢" value={p.child2Age} onChange={set("child2Age")} min={-1} max={18} unit="歳" />
            <Field label="想定寿命" value={p.lifeExpectancy} onChange={set("lifeExpectancy")} min={75} max={100} unit="歳" />
          </div>
        </>)}

        {/* === TAB 2: 支出 === */}
        {tab === 2 && (<>
          {/* 家賃 期間別 */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "14px 16px 16px", border: `1px solid ${C.border}`, marginBottom: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.accent, marginBottom: 4 }}>🏠 家賃（期間別・年額）</div>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 12 }}>住宅購入後はローン返済に自動切替</div>
            {PERIOD_LABELS.map((pl, i) => (
              <div key={i} style={{ padding: "9px 0 9px 10px", borderLeft: `3px solid ${[C.accent, C.green, C.yellow, C.purple][i]}`, marginBottom: 8, background: "#F8FAFC", borderRadius: "0 8px 8px 0" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontSize: 11, color: C.muted, fontWeight: 600 }}>{pl}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: C.dark }}>{p.rent_p[i].toLocaleString()}万円</span>
                </div>
                <input type="range" min={0} max={300} step={6} value={p.rent_p[i]}
                  onChange={e => { const nv = [...p.rent_p]; nv[i] = Number(e.target.value); setArr("rent_p")(nv); }}
                  style={{ width: "100%", accentColor: [C.accent, C.green, C.yellow, C.purple][i], cursor: "pointer" }} />
              </div>
            ))}
          </div>

          {/* 固定生活費 */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.border}`, marginBottom: 12 }}>
            <SH title="食費・日用品" icon="🛒" color={C.green} />
            <Field label="食費（年額）" value={p.food} onChange={set("food")} min={12} max={180} step={6} unit="万円" />
            <Field label="日用品（年額）" value={p.daily} onChange={set("daily")} min={0} max={60} step={1.2} unit="万円" />
            <SH title="通信・交通・レジャー" icon="🚃" color={C.yellow} />
            <Field label="通信費（年額）" value={p.comm} onChange={set("comm")} min={0} max={30} step={1.2} unit="万円" />
            <Field label="交通費（年額）" value={p.transport} onChange={set("transport")} min={0} max={60} step={1.2} unit="万円" />
            <Field label="レジャー費（年額）" value={p.leisure} onChange={set("leisure")} min={0} max={120} step={6} unit="万円" />
            <SH title="保険・医療・その他" icon="🏥" color={C.red} />
            <Field label="保険料（年額）" value={p.insurance} onChange={set("insurance")} min={0} max={150} step={1} unit="万円" />
            <Field label="被服費（年額）" value={p.clothing} onChange={set("clothing")} min={0} max={60} step={1.2} unit="万円" />
            <Field label="医療費（年額）" value={p.medical} onChange={set("medical")} min={0} max={60} step={1.2} unit="万円" />
            <Field label="その他（年額）" value={p.other} onChange={set("other")} min={0} max={100} step={1.2} unit="万円" />
          </div>

          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.border}` }}>
            <SH title="教育費（年額・1人あたり）" icon="🎒" color={C.purple} />
            <Field label="保育園（0〜5歳）" value={p.eduNursery} onChange={set("eduNursery")} min={0} max={200} step={5} unit="万円" />
            <Field label="小学校（6〜11歳）" value={p.eduElementary} onChange={set("eduElementary")} min={0} max={200} step={5} unit="万円" />
            <Field label="中学校（12〜14歳）" value={p.eduJunior} onChange={set("eduJunior")} min={0} max={200} step={5} unit="万円" />
            <Field label="高校（15〜17歳）" value={p.eduHigh} onChange={set("eduHigh")} min={0} max={200} step={5} unit="万円" />
            <Field label="大学（18〜21歳）" value={p.eduCollege} onChange={set("eduCollege")} min={0} max={200} step={5} unit="万円" />
          </div>
        </>)}

        {/* === TAB 3: 投資 === */}
        {tab === 3 && (<>
          {/* サマリー */}
          <div style={{ background: "linear-gradient(135deg,#064E3B,#1A2332)", borderRadius: 14, padding: "14px 16px", marginBottom: 12 }}>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.6)", marginBottom: 4 }}>現在の月間投資合計（2026〜2030）</div>
            <div style={{ fontSize: 24, fontWeight: 800, color: "#fff" }}>{Math.round(currentMonthlyInvest)}万円/月</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 10 }}>
              {[
                ["本人NISA", `${Math.round((p.myNisaTsumi_p[0]+p.myNisaGrowth_p[0])/12*10)/10}万/月`, C.green],
                ["妻NISA", `${Math.round((p.spouseNisaTsumi_p[0]+p.spouseNisaGrowth_p[0])/12*10)/10}万/月`, "#34D399"],
                ["本人証券", `${Math.round(p.myStockAnnual_p[0]/12*10)/10}万/月`, C.accent],
                ["妻証券", `${Math.round(p.spouseStockAnnual_p[0]/12*10)/10}万/月`, "#93C5FD"],
              ].map(([l,v,c]) => (
                <div key={l} style={{ background: "rgba(255,255,255,0.08)", borderRadius: 8, padding: "8px 10px" }}>
                  <div style={{ fontSize: 10, color: "rgba(255,255,255,0.5)" }}>{l}</div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: c }}>{v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* 本人NISA */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.green}60`, marginBottom: 12 }}>
            <SH title="本人 NISA" icon="📗" color={C.green} />
            <div style={{ background: "#F0FDF4", borderRadius: 10, padding: "10px 12px", marginTop: 4, marginBottom: 10, border: `1px solid ${C.green}40` }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#065F46" }}>
                <span>積立投資枠: {(p.myNisaTsumi_p[0]/12).toFixed(1)}万/月</span>
                <span>成長投資枠: {(p.myNisaGrowth_p[0]/12).toFixed(1)}万/月</span>
                <span style={{ fontWeight: 700 }}>計: {((p.myNisaTsumi_p[0]+p.myNisaGrowth_p[0])/12).toFixed(1)}万/月</span>
              </div>
            </div>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.green, marginBottom: 4 }}>📘 積立投資枠（上限120万/年）</div>
            <PeriodFields label="" values={p.myNisaTsumi_p} onChange={setArr("myNisaTsumi_p")} min={0} max={120} step={12} unit="万円" />
            <div style={{ fontSize: 12, fontWeight: 700, color: "#059669", marginTop: 8, marginBottom: 4 }}>📗 成長投資枠（上限240万/年）</div>
            <PeriodFields label="" values={p.myNisaGrowth_p} onChange={setArr("myNisaGrowth_p")} min={0} max={240} step={12} unit="万円" />
            <Field label="想定利回り（両枠共通）" value={p.myNisaReturn} onChange={set("myNisaReturn")} min={0} max={12} step={0.5} unit="%" />
          </div>

          {/* 妻NISA */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid #34D39960`, marginBottom: 12 }}>
            <SH title="配偶者 NISA" icon="📗" color="#34D399" />
            <div style={{ background: "#F0FDF4", borderRadius: 10, padding: "10px 12px", marginTop: 4, marginBottom: 10, border: `1px solid #34D39940` }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#065F46" }}>
                <span>積立投資枠: {(p.spouseNisaTsumi_p[0]/12).toFixed(1)}万/月</span>
                <span>成長投資枠: {(p.spouseNisaGrowth_p[0]/12).toFixed(1)}万/月</span>
                <span style={{ fontWeight: 700 }}>計: {((p.spouseNisaTsumi_p[0]+p.spouseNisaGrowth_p[0])/12).toFixed(1)}万/月</span>
              </div>
            </div>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#34D399", marginBottom: 4 }}>📘 積立投資枠（上限120万/年）</div>
            <PeriodFields label="" values={p.spouseNisaTsumi_p} onChange={setArr("spouseNisaTsumi_p")} min={0} max={120} step={12} unit="万円" />
            <div style={{ fontSize: 12, fontWeight: 700, color: "#34D399", marginTop: 8, marginBottom: 4 }}>📗 成長投資枠（上限240万/年）</div>
            <PeriodFields label="" values={p.spouseNisaGrowth_p} onChange={setArr("spouseNisaGrowth_p")} min={0} max={240} step={12} unit="万円" />
            <Field label="想定利回り（両枠共通）" value={p.spouseNisaReturn} onChange={set("spouseNisaReturn")} min={0} max={12} step={0.5} unit="%" />
          </div>

          {/* 本人証券口座 */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.accent}60`, marginBottom: 12 }}>
            <SH title="本人 証券口座（期間別・年額）" icon="📈" color={C.accent} />
            <div style={{ fontSize: 11, color: C.muted, marginTop: -4, marginBottom: 8 }}>NISA満額後の特定口座・ETF等</div>
            <PeriodFields label="" values={p.myStockAnnual_p} onChange={setArr("myStockAnnual_p")} min={0} max={600} step={12} unit="万円" />
            <Field label="想定利回り" value={p.myStockReturn} onChange={set("myStockReturn")} min={0} max={15} step={0.5} unit="%" />
          </div>

          {/* 妻証券口座 */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid #93C5FD60`, marginBottom: 12 }}>
            <SH title="配偶者 証券口座（期間別・年額）" icon="📈" color="#93C5FD" />
            <div style={{ fontSize: 11, color: C.muted, marginTop: -4, marginBottom: 8 }}>NISA満額後の特定口座・ETF等</div>
            <PeriodFields label="" values={p.spouseStockAnnual_p} onChange={setArr("spouseStockAnnual_p")} min={0} max={600} step={12} unit="万円" />
            <Field label="想定利回り" value={p.spouseStockReturn} onChange={set("spouseStockReturn")} min={0} max={15} step={0.5} unit="%" />
          </div>

          {/* 現金 */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.border}` }}>
            <SH title="現金・預金" icon="🏦" color={C.muted} />
            <Field label="現金利回り（定期など）" value={p.cashReturn} onChange={set("cashReturn")} min={0} max={3} step={0.1} unit="%" />
          </div>
        </>)}

        {/* === TAB 4: 住宅 === */}
        {tab === 4 && (() => {
          const buyAge = p.myAge + p.houseYear;
          const buyYear = 2026 + p.houseYear;
          const assetAtBuy = data.find(d => d.age === buyAge);
          const cashBeforeBuy = assetAtBuy
            ? assetAtBuy.cashAsset + p.houseCashPrice  // シミュレーション後の値なので購入額を戻して購入前を復元
            : null;
          const cashAfterBuy = assetAtBuy ? assetAtBuy.cashAsset : null;
          const shortage = cashAfterBuy !== null && cashAfterBuy < 0 ? -cashAfterBuy : 0;
          const investFilled = assetAtBuy?.investFilled ?? 0;
          const isCashOk = cashAfterBuy !== null && cashAfterBuy >= 0;
          const isFilledOk = p.houseUseInvest && investFilled > 0 && cashAfterBuy !== null && cashAfterBuy >= 0;

          return (<>
          {/* 現金一括購入 */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.border}`, marginBottom: 12 }}>
            <SH title="現金一括購入" icon="🏠" color={C.accent} />
            <div style={{ fontSize: 11, color: C.muted, marginTop: -4, marginBottom: 8 }}>購入年に現金から一括支出。購入後は家賃が0に切替わります。</div>
            <Field label="購入予定（何年後）" value={p.houseYear} onChange={set("houseYear")} min={0} max={30} unit="年後" />
            <Field label="購入価格（現金一括）" value={p.houseCashPrice} onChange={set("houseCashPrice")} min={0} max={20000} step={100} unit="万円" />
          </div>

          {/* 投資取崩し設定 */}
          {p.houseCashPrice > 0 && (() => {
            const prevData = data.find(d => d.age === buyAge - 1);
            const nisaEst = prevData ? prevData.myNisaAsset + prevData.spouseNisaAsset : 0;
            const stockEst = prevData ? prevData.myStockAsset + prevData.spouseStockAsset : 0;
            const maxW = Math.round(nisaEst + stockEst);
            const afterCash = cashAfterBuy ?? 0;
            return (
              <div style={{ background: C.panel, borderRadius: 16, padding: "14px 16px", border: "1.5px solid #F59E0B60", marginBottom: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.yellow, marginBottom: 4 }}>💡 購入時の投資取崩し</div>
                <div style={{ fontSize: 11, color: C.muted, marginBottom: 14 }}>購入年に投資口座から現金に移す金額を自由に設定。手元の現金を確保できます。</div>

                <div style={{ marginBottom: 12 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <span style={{ fontSize: 13, color: C.text }}>取崩し額</span>
                    <span style={{ fontSize: 15, fontWeight: 800, color: p.houseInvestWithdraw > 0 ? C.yellow : C.muted, background: "#F1F5F9", padding: "3px 12px", borderRadius: 20, border: "1px solid " + C.border }}>
                      {p.houseInvestWithdraw > 0 ? p.houseInvestWithdraw.toLocaleString() + "万円" : "なし"}
                    </span>
                  </div>
                  <input type="range" min={0} max={maxW > 0 ? maxW : 5000} step={100} value={p.houseInvestWithdraw}
                    onChange={e => set("houseInvestWithdraw")(Number(e.target.value))}
                    style={{ width: "100%", accentColor: C.yellow, cursor: "pointer" }} />
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: C.muted, marginTop: 2 }}>
                    <span>0（なし）</span><span>最大 {maxW.toLocaleString()}万円</span>
                  </div>
                </div>

                {maxW > 0 && (
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: p.houseInvestWithdraw > 0 ? 12 : 0 }}>
                    {[[0,"なし"],[Math.round(maxW*0.25/100)*100,"25%"],[Math.round(maxW*0.5/100)*100,"50%"],[Math.round(maxW*0.75/100)*100,"75%"],[maxW,"全額"]].map(([v,l]) => (
                      <button key={l} onClick={() => set("houseInvestWithdraw")(v)}
                        style={{ padding: "5px 12px", borderRadius: 20, border: "1.5px solid " + (p.houseInvestWithdraw === v ? C.yellow : C.border), background: p.houseInvestWithdraw === v ? "#FEF3C7" : "#F8FAFC", cursor: "pointer", fontSize: 11, fontWeight: 700, color: p.houseInvestWithdraw === v ? "#92400E" : C.muted }}>
                        {l}
                      </button>
                    ))}
                  </div>
                )}

                {p.houseInvestWithdraw > 0 && (
                  <>
                    <div style={{ fontSize: 12, color: C.muted, marginBottom: 8 }}>取崩し元:</div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 10 }}>
                      {[["nisa","NISA優先",C.green],["stock","証券優先",C.accent],["both","NISA→証券",C.yellow]].map(([v,l,c]) => (
                        <button key={v} onClick={() => set("houseInvestSource")(v)}
                          style={{ padding: "9px 4px", borderRadius: 10, border: "2px solid " + (p.houseInvestSource === v ? c : C.border), background: p.houseInvestSource === v ? c + "18" : "#F8FAFC", cursor: "pointer", fontWeight: 700, fontSize: 11, color: p.houseInvestSource === v ? c : C.muted }}>
                          {l}
                        </button>
                      ))}
                    </div>
                    <div style={{ background: "#F8FAFC", borderRadius: 10, padding: "9px 12px", fontSize: 11, color: C.muted, border: "1px solid " + C.border }}>
                      {p.houseInvestSource === "nisa" && ("NISA残高（約" + Math.round(nisaEst).toLocaleString() + "万円）から取崩し")}
                      {p.houseInvestSource === "stock" && ("証券残高（約" + Math.round(stockEst).toLocaleString() + "万円）から取崩し")}
                      {p.houseInvestSource === "both" && ("NISA（約" + Math.round(nisaEst).toLocaleString() + "万）→不足分は証券（約" + Math.round(stockEst).toLocaleString() + "万）から取崩し")}
                    </div>
                  </>
                )}
              </div>
            );
          })()}

          {/* 購入サマリー */}
          {p.houseCashPrice > 0 && (() => {
            const afterCash = cashAfterBuy ?? 0;
            const isGood = afterCash >= 0;
            return (
              <div style={{ background: isGood ? "linear-gradient(135deg,#064E3B,#1A2332)" : "linear-gradient(135deg,#7F1D1D,#1A2332)", borderRadius: 14, padding: "16px 18px", marginBottom: 12 }}>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", marginBottom: 12 }}>📊 購入シミュレーション — {buyYear}年（{buyAge}歳）</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  {[
                    ["購入価格", formatMan(p.houseCashPrice), "#fff"],
                    investFilled > 0 ? ["投資取崩し額", formatMan(investFilled), C.yellow] : null,
                    ["現金残高（購入後）", formatMan(afterCash), afterCash >= 0 ? C.green : C.red],
                    ["判定", isGood ? (investFilled > 0 ? "✓ 取崩しで対応" : "✓ 現金で賄える") : "⚠ 資金不足", isGood ? C.green : C.red],
                  ].filter(Boolean).map(([l,v,c]) => (
                    <div key={l}>
                      <div style={{ fontSize: 10, color: "rgba(255,255,255,0.45)", marginBottom: 2 }}>{l}</div>
                      <div style={{ fontSize: 15, fontWeight: 800, color: c }}>{v}</div>
                    </div>
                  ))}
                </div>
                {afterCash < 0 && (
                  <div style={{ marginTop: 12, background: "rgba(239,68,68,0.2)", borderRadius: 8, padding: "8px 12px", fontSize: 11, color: "#FCA5A5" }}>
                    ⚠ まだ{formatMan(-afterCash)}不足。取崩し額を増やすか購入時期を遅らせてください。
                  </div>
                )}
                {afterCash >= 0 && afterCash < 500 && (
                  <div style={{ marginTop: 12, background: "rgba(245,158,11,0.2)", borderRadius: 8, padding: "8px 12px", fontSize: 11, color: "#FCD34D" }}>
                    💡 現金が少なめです。緊急予備として300〜500万円の確保を推奨します。
                  </div>
                )}
              </div>
            );
          })()}

          {/* ローン（参考） */}          {/* ローン（参考） */}
          <div style={{ background: C.panel, borderRadius: 16, padding: "0 16px 16px", border: `1px solid ${C.border}` }}>
            <SH title="ローン（参考・比較用）" icon="🏦" color={C.muted} />
            <div style={{ fontSize: 11, color: C.muted, marginTop: -4, marginBottom: 8 }}>借入額0=ローンなし</div>
            <Field label="借入額" value={p.houseLoan} onChange={set("houseLoan")} min={0} max={10000} step={100} unit="万円" />
            <Field label="金利" value={p.loanRate} onChange={set("loanRate")} min={0.3} max={5} step={0.1} unit="%" />
            <Field label="返済期間" value={p.loanYears} onChange={set("loanYears")} min={10} max={35} unit="年" />
            {p.houseLoan > 0 && (
              <div style={{ background: "#F8FAFC", borderRadius: 10, padding: "12px", marginTop: 10, border: `1px solid ${C.border}` }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                  {[["月額返済",`${loanMonthlyMan.toLocaleString()}万円`],["利息総額",formatMan(loanMonthlyMan*12*p.loanYears-p.houseLoan)]].map(([l,v]) => (
                    <div key={l}><div style={{ fontSize: 10, color: C.muted }}>{l}</div><div style={{ fontSize: 14, fontWeight: 700, color: C.dark }}>{v}</div></div>
                  ))}
                </div>
              </div>
            )}
          </div>
          </>);
        })()}
      </div>

        {/* === TAB 5: ライフイベント === */}
        {tab === 5 && (() => {
          const addEvent = () => setP(prev => ({
            ...prev,
            events: [...prev.events, { id: Date.now(), name: "新しいイベント", year: 5, amount: 100, icon: "💰" }]
          }));
          const CATS = [
            { id:"car", icon:"🚗", name:"車", default:300 },
            { id:"appl", icon:"📺", name:"家電", default:50 },
            { id:"travel", icon:"✈️", name:"旅行", default:50 },
            { id:"furn", icon:"🛋️", name:"家具", default:80 },
            { id:"med", icon:"🏥", name:"医療", default:100 },
            { id:"edu", icon:"🎓", name:"習い事", default:30 },
            { id:"other", icon:"💰", name:"その他", default:100 },
          ];
          const removeEvent = (id) => setP(prev => ({ ...prev, events: prev.events.filter(e => e.id !== id) }));
          const updateEvent = (id, field, value) => setP(prev => ({
            ...prev,
            events: prev.events.map(e => e.id === id ? { ...e, [field]: value } : e)
          }));

          const sorted = [...p.events].sort((a,b) => a.year - b.year);
          const totalByYear = {};
          p.events.forEach(ev => { totalByYear[ev.year] = (totalByYear[ev.year]||0) + ev.amount; });

          return (<>
            {/* サマリー */}
            <div style={{ background: "linear-gradient(135deg,#4C1D95,#1A2332)", borderRadius: 14, padding: "14px 16px", marginBottom: 12 }}>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", marginBottom: 4 }}>登録イベント合計</div>
              <div style={{ fontSize: 24, fontWeight: 800, color: "#fff" }}>{formatMan(p.events.reduce((s,e)=>s+e.amount,0))}</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
                {sorted.map(ev => (
                  <span key={ev.id} style={{ background: "rgba(255,255,255,0.1)", borderRadius: 20, padding: "3px 10px", fontSize: 10, color: "#E9D5FF" }}>
                    {2026+ev.year}年 {ev.name} {ev.amount}万
                  </span>
                ))}
              </div>
            </div>

            {/* イベント一覧 */}
            {sorted.map(ev => (
              <div key={ev.id} style={{ background: C.panel, borderRadius: 16, padding: "14px 16px", border: "1.5px solid #8B5CF640", marginBottom: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                  <span style={{ fontSize: 18, marginRight: 4 }}>{ev.icon || "💰"}</span>
                  <input
                    value={ev.name}
                    onChange={e => updateEvent(ev.id, "name", e.target.value)}
                    style={{ fontSize: 14, fontWeight: 700, color: C.dark, border: "none", borderBottom: "2px solid #8B5CF6", background: "transparent", outline: "none", flex: 1, paddingBottom: 2 }}
                  />
                  <button onClick={() => removeEvent(ev.id)}
                    style={{ background: "#FEE2E2", border: "none", cursor: "pointer", borderRadius: 8, padding: "4px 10px", fontSize: 11, color: C.red, fontWeight: 700, marginLeft: 10, flexShrink: 0 }}>
                    削除
                  </button>
                </div>
                <div style={{ padding: "8px 0", borderBottom: "1px solid " + C.border }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                    <span style={{ fontSize: 12, color: C.muted }}>発生時期</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: C.accent }}>{2026+ev.year}年（本人{p.myAge+ev.year}歳）</span>
                  </div>
                  <input type="range" min={0} max={44} step={1} value={ev.year}
                    onChange={e => updateEvent(ev.id, "year", Number(e.target.value))}
                    style={{ width: "100%", accentColor: "#8B5CF6", cursor: "pointer" }} />
                </div>
                <div style={{ padding: "8px 0" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                    <span style={{ fontSize: 12, color: C.muted }}>金額</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: C.purple }}>{ev.amount.toLocaleString()}万円</span>
                  </div>
                  <input type="range" min={10} max={5000} step={10} value={ev.amount}
                    onChange={e => updateEvent(ev.id, "amount", Number(e.target.value))}
                    style={{ width: "100%", accentColor: "#8B5CF6", cursor: "pointer" }} />
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: C.muted, marginTop: 2 }}>
                    <span>10万円</span><span>5,000万円</span>
                  </div>
                </div>
              </div>
            ))}

            {/* カテゴリから追加 */}
            <div style={{ background: C.panel, borderRadius: 14, padding: "14px 16px", border: "2px dashed #8B5CF640" }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: C.purple, marginBottom: 10 }}>＋ カテゴリから追加</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8 }}>
                {CATS.map(cat => (
                  <button key={cat.id} onClick={() => setP(prev => ({ ...prev, events: [...prev.events, { id: Date.now(), name: cat.name, year: 3, amount: cat.default, icon: cat.icon }] }))}
                    style={{ padding: "10px 4px", borderRadius: 10, border: "1.5px solid #8B5CF630", background: "#F5F3FF", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
                    <span style={{ fontSize: 20 }}>{cat.icon}</span>
                    <span style={{ fontSize: 10, fontWeight: 700, color: C.purple }}>{cat.name}</span>
                    <span style={{ fontSize: 9, color: C.muted }}>{cat.default}万</span>
                  </button>
                ))}
                <button onClick={addEvent}
                  style={{ padding: "10px 4px", borderRadius: 10, border: "1.5px dashed #8B5CF680", background: "#FAF5FF", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
                  <span style={{ fontSize: 20 }}>✏️</span>
                  <span style={{ fontSize: 10, fontWeight: 700, color: C.purple }}>自由入力</span>
                  <span style={{ fontSize: 9, color: C.muted }}>100万</span>
                </button>
              </div>
            </div>
          </>);
        })()}

      {/* タブバー */}
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: C.dark, display: "flex", borderTop: "1px solid #2D3748", zIndex: 200, paddingBottom: "env(safe-area-inset-bottom,0px)" }}>
        {TABS.map((t, i) => (
          <button key={i} onClick={() => setTab(i)} style={{ flex: 1, padding: "9px 2px 8px", background: "none", border: "none", cursor: "pointer", borderTop: tab === i ? `2.5px solid ${C.accent}` : "2.5px solid transparent", display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
            <span style={{ fontSize: 16 }}>{t.icon}</span>
            <span style={{ fontSize: 9, fontWeight: 700, color: tab === i ? C.accent : C.muted }}>{t.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
